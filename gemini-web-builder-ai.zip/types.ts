
export interface Comment {
  id: string;
  author: string;
  content: string;
  date: string;
  isApproved: boolean;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content?: string; // Content is now optional in the list view to save memory
  tag: string;
  date: string;
  img: string;
  author?: string;
}

export interface ServiceDetail {
  id: string;
  title: string;
  shortDesc: string;
  fullDesc: string;
  htmlContent: string;
  heroImg: string;
  process: { title: string; desc: string }[];
  gallery: string[];
  icon: string;
}

export interface District {
  id: string;
  name: string;
  side: 'Europe' | 'Anatolia';
}

export interface WebsiteConfig {
  siteName: string;
  primaryColor: string;
  secondaryColor: string;
  // Legacy support
  pages: any;
}

export interface LeadData {
  source: 'chat' | 'form';
  name?: string;
  phone: string;
  details?: string;
  location?: string;
}

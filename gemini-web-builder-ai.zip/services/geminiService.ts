
import { GoogleGenAI, Type } from "@google/genai";
import { WebsiteConfig } from "../types";

// Window arayüzüne aistudio özelliklerini ekliyoruz
declare global {
  interface AIStudio {
    hasSelectedApiKey: () => Promise<boolean>;
    openSelectKey: () => Promise<void>;
  }
  interface Window {
    aistudio?: AIStudio;
  }
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// --- UTILS ---
const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Remove data URL prefix (e.g. "data:image/png;base64,")
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

// --- EXISTING FUNCTION ---
export const generateWebsiteStructure = async (prompt: string): Promise<WebsiteConfig> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Bir web sitesi oluşturmak istiyorum. Konu: ${prompt}. Lütfen modern, profesyonel ve etkileyici bir landing page yapısı oluştur. Cevabını JSON formatında ver.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          siteName: { type: Type.STRING },
          primaryColor: { type: Type.STRING },
          secondaryColor: { type: Type.STRING },
          sections: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                type: { type: Type.STRING },
                title: { type: Type.STRING },
                content: { type: Type.STRING },
                items: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: { title: { type: Type.STRING }, description: { type: Type.STRING }, icon: { type: Type.STRING } }
                  }
                }
              },
              required: ['id', 'type', 'title', 'content']
            }
          }
        },
        required: ['siteName', 'primaryColor', 'secondaryColor', 'sections']
      }
    }
  });
  return JSON.parse(response.text || '{}');
};

// --- NEW AI FEATURES ---

// 1. CHATBOT (Thinking Mode & Google Search & Sales Persona)
export const chatWithGemini = async (
  message: string, 
  mode: 'standard' | 'thinking' | 'search',
  context: string = 'general'
): Promise<{ text: string, sources?: any[] }> => {
  
  let model = 'gemini-3-flash-preview';
  let config: any = {};
  
  // Custom System Instruction based on Context to act as a Sales Agent
  // UPDATED: Removed "Logistics" terminology. Focused on Moving/Storage.
  let systemInstruction = "Sen Sandıkçıoğlu Nakliyat'ın kıdemli taşınma planlayıcısısın. " + 
    "İsmin 'Asistan'. Çok nazik, profesyonel, güven veren ve çözüm odaklısın. " +
    "KURAL: Asla 'Lojistik' veya 'International' kelimelerini kullanma. Biz evden eve nakliyat, ofis taşıma ve eşya depolama firmasıyız. " +
    "Amacın müşterinin taşınma detaylarını (nereden, nereye, ne zaman, oda sayısı) öğrenmek ve telefon numarasını alıp satış ekibine yönlendirmek. " +
    "Fiyat vermekten kaçın, 'ekspertiz sonrası net fiyat verebiliriz' de. " + 
    "Müşteri stresliyse onu rahatlat, sigortalı ve ambalajlı çalıştığımızı vurgula." +
    "Email adresimiz: sandikcioglunakliyat@gmail.com. Telefon: 0531 366 99 36.";

  if (context === 'storage') {
    systemInstruction += " Konu: Eşya Depolama. Depolarımızın rutubetsiz, kameralı, kişiye özel kilitli oda sistemli ve sigortalı olduğunu vurgula.";
  } else if (context === 'office') {
    systemInstruction += " Konu: Ofis Taşıma. İş kaybını önlemek için hızlı ve planlı taşıma yaptığımızı, dosyaları karıştırmadığımızı, mobilya montajını yaptığımızı vurgula.";
  }

  if (mode === 'thinking') {
    model = 'gemini-3-pro-preview';
    config = {
      thinkingConfig: { thinkingBudget: 32768 }, // Max budget for deep reasoning
      systemInstruction: systemInstruction
    };
  } else if (mode === 'search') {
    model = 'gemini-3-flash-preview';
    config = {
      tools: [{ googleSearch: {} }], // Search grounding
      systemInstruction: systemInstruction
    };
  } else {
    // Standard chatbot
    model = 'gemini-3-pro-preview';
    config = {
      systemInstruction: systemInstruction
    };
  }

  const response = await ai.models.generateContent({
    model,
    contents: message,
    config
  });

  const text = response.text || "Üzgünüm, şu an yanıt veremiyorum. Lütfen 0531 366 99 36 numarasından bize ulaşın.";
  const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

  return { text, sources };
};

// 2. IMAGE GENERATION (Aspect Ratio Control)
export const generateCustomImage = async (prompt: string, aspectRatio: string): Promise<string> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: {
      parts: [{ text: prompt + " photorealistic, interior design, architectural photography, 8k resolution" }]
    },
    config: {
      imageConfig: {
        aspectRatio: aspectRatio as any, // "1:1", "16:9", etc.
        imageSize: "1K"
      }
    }
  });

  // Extract image
  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  throw new Error("Görsel oluşturulamadı.");
};

// 3. IMAGE EDITING (Nano Banana / Gemini 2.5 Flash Image)
export const editUploadedImage = async (imageFile: File, prompt: string): Promise<string> => {
  const base64Data = await fileToBase64(imageFile);
  
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: imageFile.type,
            data: base64Data
          }
        },
        { text: prompt }
      ]
    }
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  throw new Error("Görsel düzenlenemedi.");
};

// 4. VIDEO GENERATION (Veo)
export const generateVeoVideo = async (imageFile: File, prompt: string): Promise<string> => {
  // Check for paid API key requirement
  if (window.aistudio && window.aistudio.hasSelectedApiKey) {
    const hasKey = await window.aistudio.hasSelectedApiKey();
    if (!hasKey) {
      await window.aistudio.openSelectKey();
      // Throw specific error to trigger retry in UI after selection
      throw new Error("API_KEY_REQUIRED"); 
    }
  }

  // Re-initialize AI to ensure key is picked up if just selected
  const freshAi = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const base64Data = await fileToBase64(imageFile);

  let operation = await freshAi.models.generateVideos({
    model: 'veo-3.1-fast-generate-preview',
    prompt: prompt || "Cinematic camera movement, high quality, 4k",
    image: {
      imageBytes: base64Data,
      mimeType: imageFile.type
    },
    config: {
      numberOfVideos: 1,
      resolution: '720p',
      aspectRatio: '16:9' // Defaulting to landscape
    }
  });

  // Poll for completion
  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 5000));
    operation = await freshAi.operations.getVideosOperation({ operation });
  }

  const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!videoUri) throw new Error("Video üretilemedi.");

  // Fetch actual video bytes
  const vidResponse = await fetch(`${videoUri}&key=${process.env.API_KEY}`);
  const vidBlob = await vidResponse.blob();
  return URL.createObjectURL(vidBlob);
};

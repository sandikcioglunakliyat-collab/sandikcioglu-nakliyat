
import { test, expect } from '@playwright/test';

test.describe('Sandıkçıoğlu Nakliyat E2E Tests', () => {

  // Adjust base URL as needed for the local environment
  test.beforeEach(async ({ page }) => {
    await page.goto('http://localhost:3000/');
  });

  test('User can navigate to a service detail page', async ({ page }) => {
    // Verify Homepage Title
    await expect(page.locator('h1')).toContainText('Hayallerinizi');

    // Navigate to 'Evden Eve Nakliyat' from the Services Grid or Menu
    // We look for a link that points to the specific service and click it
    const serviceLink = page.locator('a[href="#/hizmet/evden-eve"]').first();
    await serviceLink.click();

    // Verify URL and Page Content
    await expect(page).toHaveURL(/.*#\/hizmet\/evden-eve/);
    await expect(page.locator('h1')).toContainText('Evden Eve Nakliyat');
    
    // Check if Technical Details section is visible
    await expect(page.getByText('Teknolojik Altyapı')).toBeVisible();
  });

  test('User can submit a quote request via the modal', async ({ page }) => {
    // Setup listener for the success alert
    page.on('dialog', async dialog => {
      // Updated assertion to match new alert text
      expect(dialog.message()).toContain('Bilgileriniz alındı');
      await dialog.accept();
    });

    // Open Quote Modal
    const quoteBtn = page.getByRole('button', { name: 'Hemen Fiyat Al' }).first();
    await quoteBtn.click();

    // Verify Modal is visible
    const modal = page.locator('form');
    await expect(modal).toBeVisible();

    // Step 1: Fill details
    // The select options are updated in the code.
    await modal.locator('select').nth(0).selectOption('Kadıköy'); // From
    await modal.locator('select').nth(1).selectOption('Beşiktaş'); // To
    await modal.locator('select').nth(2).selectOption('3+1'); // Room Size

    // Proceed to Step 2
    await modal.getByRole('button', { name: 'Devam Et' }).click();

    // Step 2: Contact Info
    await modal.getByPlaceholder('Adınız').fill('Test Müşteri');
    await modal.getByPlaceholder('05XX XXX XX XX').fill('05550001122');
    
    // Submit Form
    await modal.getByRole('button', { name: 'Fiyatı Gör' }).click();
  });

  test('User can view blog posts', async ({ page }) => {
    // Navigate to Blog page via Header Menu
    const blogLink = page.getByRole('link', { name: 'Blog' }).first();
    await blogLink.click();

    // Verify Blog List Page
    await expect(page).toHaveURL(/.*#\/blog/);
    await expect(page.locator('h1')).toContainText('Blog & Haberler');

    // Click on the first blog post card
    const firstPost = page.locator('a[href^="#/blog/"]').first();
    // Store title to verify later
    const postTitle = await firstPost.locator('h2').innerText();
    await firstPost.click();

    // Verify Blog Detail Page
    // Playwright handles the hash navigation
    await expect(page).toHaveURL(/.*#\/blog\/\d+/);
    await expect(page.locator('h1')).toContainText(postTitle);
  });

});
